CREATE DATABASE IF NOT EXISTS hospital_auth;
USE hospital_auth;

DROP TABLE IF EXISTS users;

CREATE TABLE users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  username VARCHAR(255) NOT NULL UNIQUE,
  password VARCHAR(255) NOT NULL,
  role ENUM('paciente', 'doctor', 'admin') DEFAULT 'paciente'
);

-- Contraseña es "12345"
INSERT INTO users (username, password, role) VALUES
('admin1', '$2a$10$f6kxP9V6YPyMTcqSG/jcYujK75cCfnFG9SBXXWkSVN2CRupJo4RW.', 'admin');